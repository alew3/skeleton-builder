<script>
	import { Edge } from 'svelvet';
</script>

<Edge let:path animate color="red" width="1" />
