Better protected routs
https://www.youtube.com/watch?v=ieECVME5ZLU

source
https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqa0ZKVzdSa0NqMW5jaUdRWkdFM2lQYm1qcGFBd3xBQ3Jtc0trRzR0TmNvTjZDWmVBMlZ1VnZQRV8yWDZHM3RPcGpXSkJabDhmeE1xb193b3hLQkVMX0hJQVJnSG90YzRMRDJWRzJqSlZWNTBaZFNDMjZtcXUyZ1dTMDB4ODgycWtwdTVGTW1haUJuYWp4WVExcHlCMA&q=https%3A%2F%2Fgithub.com%2Fhuntabyte%2Fbetter-redirects&v=ieECVME5ZLU 






# create-svelte

Everything you need to build a Svelte project, powered by [`create-svelte`](https://github.com/sveltejs/kit/tree/master/packages/create-svelte).

## Creating a project

If you're seeing this, you've probably already done this step. Congrats!

```bash
# create a new project in the current directory
npm create svelte@latest

# create a new project in my-app
npm create svelte@latest my-app
```

## Developing

Once you've created a project and installed dependencies with `npm install` (or `pnpm install` or `yarn`), start a development server:

```bash
npm run dev

# or start the server and open the app in a new browser tab
npm run dev -- --open
```

## Building

To create a production version of your app:

```bash
npm run build
```

You can preview the production build with `npm run preview`.

> To deploy your app, you may need to install an [adapter](https://kit.svelte.dev/docs/adapters) for your target environment.
